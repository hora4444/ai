-- [III] JOIN : 2개 이상의 테이블을 연결하여 데이터를 검색하는 방법
SELECT * FROM EMP WHERE ENAME='SCOTT'; -- 사번, 이름, 업무(직책), 상사사번, 입사일, 급여, 상여, 부서번호
SELECT * FROM DEPT; -- 부서번호, 부서명, 부서위치
-- 사번~부서번호, 부서명, 부서위치
SELECT * FROM EMP, DEPT WHERE ENAME='SCOTT'; -- CROSS JOIN(무의미)

-- ★ 1. EQUI JOIN ★ : 공통 필드값이 일치되는 조건만 JOIN
SELECT *                -- (3)
    FROM EMP E, DEPT D  -- (1) 이후 2,3번 줄에선 테이블의 별칭으로만 사용 가능
    WHERE ENAME='SCOTT' AND E.DEPTNO=D.DEPTNO;  -- (2)
SELECT EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, D.*
    FROM EMP E, DEPT D
    WHERE E.DEPTNO=D.DEPTNO;
    -- EX1. 급여가 2000이상인 직원의 이름, 직책, 급여, 부서명, 근무지
    SELECT ENAME, JOB, SAL, DNAME, LOC FROM EMP E, DEPT D WHERE SAL >=2000 AND E.DEPTNO = D.DEPTNO;
    -- EX2. 20번 부서 직원만 이름, 부서번호, 근무지
    SELECT ENAME, D.DEPTNO, LOC FROM EMP E, DEPT D WHERE E.DEPTNO=D.DEPTNO AND D.DEPTNO=20;
    -- EX3. 근무지(LOC)가 CHICAGO인 사람의 이름, 급여, 부서번호를 출력
    SELECT ENAME, SAL, D.DEPTNO FROM EMP E, DEPT D WHERE E.DEPTNO=D.DEPTNO AND LOC='CHICAGO';
    --EX4. JOB이 'SALESMAN' 이거나 'MANAGER'인 사원의 이름, 급여, 상여, 연봉(SAL+COMM)*12, 부서명 , 연봉 내림차순
    SELECT ENAME, SAL, NVL(COMM,0), (SAL+NVL(COMM,0))*12 ANNUALSAL , DNAME
        FROM EMP E , DEPT D
        WHERE E.DEPTNO=D.DEPTNO AND JOB IN ('SALESMAN', 'MANAGER')
        ORDER BY ANNUALSAL DESC;
    -- EX5. COMM이 NULL이고 SAL이 1200이상인 사원의 이름, 급여, 부서번호, 부서명
        -- 부서명 오름차순, 급여 큰 순 정렬
    SELECT ENAME, SAL, D.DEPTNO, DNAME
        FROM EMP E, DEPT D
        WHERE E.DEPTNO=D.DEPTNO AND COMM IS NULL AND SAL >=1200
        ORDER BY DNAME ,SAL DESC;
        
--	탄탄 다지기
--	뉴욕에서 근무하는 사원의 이름과 급여를 출력하시오
SELECT ENAME, SAL FROM EMP E, DEPT D WHERE E.DEPTNO = D.DEPTNO AND LOC='NEW YORK';
--	ACCOUNTING 부서 소속 사원의 이름과 입사일을 출력하시오
SELECT ENAME, HIREDATE FROM EMP E, DEPT D WHERE E.DEPTNO=D.DEPTNO AND DNAME='ACCOUNTING';
--	직급이 MANAGER인 사원의 이름, 부서명을 출력하시오
SELECT ENAME, DNAME FROM EMP E, DEPT D WHERE E.DEPTNO = D.DEPTNO AND JOB ='MANAGER';
--	Comm이 null이 아닌 사원의 이름, 급여, 부서코드, 근무지를 출력하시오.
SELECT ENAME, SAL, D.DEPTNO, LOC FROM EMP E, DEPT D WHERE E.DEPTNO = D.DEPTNO AND COMM IS NOT NULL;

-- 2. NON EQUI JOIN : 동일한 컬럼없이 다른 조건을 사용하여 조인
SELECT * FROM EMP WHERE ENAME='SCOTT';
SELECT * FROM SALGRADE;
SELECT * FROM EMP, SALGRADE WHERE ENAME = 'SCOTT' AND SAL >= LOSAL AND SAL <= HISAL; -- 공통된 필드명이 없다면 굳이 테이블명을 바꿀 필요는 없음
SELECT * FROM EMP, SALGRADE WHERE ENAME = 'SCOTT' AND SAL BETWEEN LOSAL AND HISAL;
    -- EX1. 모든 사원의 사번, 이름, 급여, 상여등급(1등급, 2등급 ....), 상사사번
    SELECT EMPNO, ENAME, SAL, GRADE || '등급' "GRADE", MGR FROM EMP, SALGRADE WHERE SAL BETWEEN LOSAL AND HISAL;

--	탄탄다지기 연습문제
--	Comm이 null이 아닌 사원의 이름, 급여, 등급, 부서번호, 부서이름, 근무지를 출력하시오.
SELECT ENAME, SAL, GRADE, E.EMPNO, DNAME, LOC FROM EMP E, DEPT D, SALGRADE WHERE E.DEPTNO = D.DEPTNO AND COMM IS NOT NULL AND SAL BETWEEN LOSAL AND HISAL;
--	이름, 급여, 입사일, 급여등급
SELECT ENAME, SAL, HIREDATE, GRADE FROM EMP, SALGRADE WHERE SAL BETWEEN LOSAL AND HISAL;
--	이름, 급여, 급여등급, 연봉, 부서명을 부서명순으로 정렬하여 출력. 부서가 같으면 연봉순. 연봉=(sal+comm)*12 comm이 null이면 0
SELECT ENAME, SAL, GRADE, (SAL+NVL(COMM,0))*12 ANNUALSAL, DNAME FROM EMP E, DEPT D, SALGRADE 
    WHERE E.DEPTNO = D.DEPTNO AND SAL BETWEEN LOSAL AND HISAL ORDER BY ANNUALSAL DESC;
--	이름, 업무, 급여, 등급, 부서코드, 부서명 출력. 급여가 1000~3000사이. 정렬조건 : 부서별, 부서같으면 업무별, 업무같으면 급여 큰순
SELECT ENAME, JOB, SAL, GRADE, D.DEPTNO, DNAME FROM EMP E, DEPT D, SALGRADE 
    WHERE E.DEPTNO = D.DEPTNO AND SAL BETWEEN 1000 AND 3000 AND SAL BETWEEN LOSAL AND HISAL;
--	이름, 급여, 등급, 입사일, 근무지. 81년에 입사한 사람. 등급 큰순
SELECT ENAME, SAL, GRADE, HIREDATE, DNAME FROM EMP E, DEPT D, SALGRADE 
    WHERE E.DEPTNO = D.DEPTNO AND SAL BETWEEN LOSAL AND HISAL AND TO_CHAR(HIREDATE,'RR') = 81
    ORDER BY GRADE DESC; 
    
-- ★ <총 연습문제>
Part1
--1. 모든 사원에 대한 이름, 부서번호, 부서명을 출력하는 SELECT 문장을 작성하여라.
SELECT ENAME, D.DEPTNO, DNAME 
    FROM EMP E, DEPT D 
    WHERE E.DEPTNO = D.DEPTNO;
--2. NEW YORK에서 근무하고 있는 사원에 대하여 이름, 업무, 급여, 부서명을 출력
SELECT ENAME, JOB, SAL, DNAME 
    FROM EMP E, DEPT D 
    WHERE E.DEPTNO = D.DEPTNO AND LOC='NEW YORK';
--3. 보너스를 받는 사원에 대하여 이름,부서명,위치를 출력
SELECT ENAME, DNAME, LOC 
    FROM EMP E, DEPT D 
    WHERE E.DEPTNO = D.DEPTNO AND (COMM !=0 OR COMM IS NOT NULL);
--4. 이름 중 L자가 있는 사원에 대하여 이름,업무,부서명,위치를 출력
SELECT ENAME, JOB, DNAME, LOC 
    FROM EMP E, DEPT D 
    WHERE E.DEPTNO = D.DEPTNO AND ENAME LIKE '%L%';
--5. 사번, 사원명, 부서코드, 부서명을 검색하라(단, 사원명기준으로 오름차순 정렬)
SELECT EMPNO, ENAME, D.DEPTNO, DNAME 
    FROM EMP E, DEPT D WHERE E.DEPTNO = D.DEPTNO
    ORDER BY ENAME;
--6. 사번, 사원명, 급여, 부서명을 검색하라. 
    --단 급여가 2000이상인 사원에 대하여 급여를 기준으로 내림차순으로 정렬하시오
SELECT EMPNO, ENAME, SAL, DNAME 
    FROM EMP E, DEPT D 
    WHERE E.DEPTNO = D.DEPTNO AND SAL >=2000 
    ORDER BY SAL DESC;
--7. 사번, 사원명, 업무, 급여, 부서명을 검색하시오. 단 업무가 MANAGER이며 급여가 2500이상인
-- 사원에 대하여 사번을 기준으로 오름차순으로 정렬하시오.
SELECT EMPNO, ENAME, JOB, SAL, DNAME 
    FROM EMP E, DEPT D 
    WHERE E.DEPTNO = D.DEPTNO AND JOB='MANAGER' AND SAL>=2500 
    ORDER BY EMPNO;
--8. 사번, 사원명, 업무, 급여, 등급을 검색하시오(단, 급여기준 내림차순으로 정렬)
SELECT EMPNO, ENAME, JOB, SAL, GRADE 
    FROM EMP E, DEPT D, SALGRADE 
    WHERE E.DEPTNO = D.DEPTNO AND SAL BETWEEN LOSAL AND HISAL 
    ORDER BY SAL DESC;

    
    